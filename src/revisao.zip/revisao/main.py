from Quiz import *

if __name__ == "__main__":

    q1 = Quiz("POO", "Rafael", 10, 5)
    print(q1)